Pentru a porni proiectul acesta trebuie deschis în intellij idea (recomandat) și să se dea run pe metoda main din clasa: OfficeItApplication

Accesați localhost:8080 pentru a intra în aplicație. Acolo aplicația va prezenta o pagină web cu o bară de meniu care conține:
 - Products
 - Clients
 - Calculate Price

Products -> Lista de produse cu posibilitatea de a importa produse prin fișier în format JSON sau XML. 'new-products.json' și 'new-products.xml' sunt atașate ca modele pachetului arhivat.

Clients -> Lista de clienți existenți

Calculate Price -> Posibilitatea de a calcula prețul total și prețul rebate în funcție de lista de clienți și lista de produse. Prețurile se calculează pe baza inserării id-ului de client și a unui sau mai multe id-uri de produse.
Ex: inserați 1 la id de client și 100,99,98 la id de produse apoi apăsați "Calcualate Price" pentru a vizualiza prețurile.
